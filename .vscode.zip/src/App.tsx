import React, { useState } from "react";
import {
  Rocket,
  Menu,
  MessageSquare,
  BarChart2,
  Layers,
  Users,
} from "lucide-react";

// ✅ Campaign type definition
interface Campaign {
  type: string;
  name: string;
  target: string;
  budget: string;
  product?: {
    productName: string;
    productPrice: string;
    productDesc: string;
  } | null;
  service?: {
    serviceName: string;
    serviceDesc: string;
    serviceAudience: string;
  } | null;
}

export default function CEROApp() {
  type Page =
    | "welcome"
    | "signup"
    | "promotionSelect"
    | "promotionDetails"
    | "promotionExtra"
    | "postPreview"
    | "home"
    | "analysis"
    | "chat"
    | "services"
    | "about";

  const [page, setPage] = useState<Page>("welcome");
  const [menuOpen, setMenuOpen] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [formData, setFormData] = useState<any>({
    name: "",
    email: "",
    password: "",
    campaignType: "",
    campaignName: "",
    targetAudience: "",
    budget: "",
    product: { productName: "", productPrice: "", productDesc: "" },
    service: { serviceName: "", serviceDesc: "", serviceAudience: "" },
  });

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev: any) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (page === "signup") {
      setIsAuthenticated(true);
      setPage("home");
    } else if (page === "promotionDetails") {
      setPage("promotionExtra");
    } else if (page === "promotionExtra") {
      const newCampaign: Campaign = {
        type: formData.campaignType,
        name: formData.campaignName,
        target: formData.targetAudience,
        budget: formData.budget,
        product:
          formData.campaignType === "product" ? formData.product : null,
        service:
          formData.campaignType === "service" ? formData.service : null,
      };
      setCampaigns([...campaigns, newCampaign]);
      setPage("postPreview");
    }
  };

  const Navbar = () => (
    <nav className="flex justify-between items-center p-4 bg-white shadow">
      <h1
        className="text-xl font-bold text-blue-600 cursor-pointer"
        onClick={() => setPage("home")}
      >
        CERO
      </h1>
      <button onClick={() => setMenuOpen(!menuOpen)}>
        <Menu className="w-6 h-6" />
      </button>
      {menuOpen && (
        <div className="absolute top-16 right-4 bg-white shadow-lg rounded-xl w-48 p-2">
          <button
            onClick={() => setPage("home")}
            className="block w-full text-left px-4 py-2 hover:bg-gray-100"
          >
            Home
          </button>
          <button
            onClick={() => setPage("analysis")}
            className="block w-full text-left px-4 py-2 hover:bg-gray-100"
          >
            Analysis
          </button>
          <button
            onClick={() => setPage("chat")}
            className="block w-full text-left px-4 py-2 hover:bg-gray-100"
          >
            Chat
          </button>
          <button
            onClick={() => setPage("services")}
            className="block w-full text-left px-4 py-2 hover:bg-gray-100"
          >
            Services
          </button>
          <button
            onClick={() => setPage("about")}
            className="block w-full text-left px-4 py-2 hover:bg-gray-100"
          >
            About Us
          </button>
        </div>
      )}
    </nav>
  );

  const renderPage = () => {
    switch (page) {
      case "welcome":
        return (
          <div className="h-screen w-full flex items-center justify-center bg-gradient-to-br from-blue-600 to-purple-700 text-white text-center p-6">
            <div>
              <h1 className="text-4xl md:text-6xl font-bold mb-6 animate-bounce">
                Welcome to CERO
              </h1>
              <p className="text-xl mb-8">
                The future of digital promotion powered by AI
              </p>
              <button
                onClick={() => setPage("signup")}
                className="bg-white text-blue-600 px-6 py-3 rounded-full font-semibold hover:bg-gray-200 transition"
              >
                Get Started
              </button>
            </div>
          </div>
        );

      case "signup":
        return (
          <div className="min-h-screen flex items-center justify-center bg-gray-100 p-4">
            <div className="bg-white p-8 rounded-2xl shadow-xl w-full max-w-md">
              <h2 className="text-2xl font-bold mb-6 text-center">
                Create Your Account
              </h2>
              <form onSubmit={handleSubmit} className="space-y-4">
                <input
                  type="text"
                  name="name"
                  placeholder="Full Name"
                  value={formData.name}
                  onChange={handleInputChange}
                  className="w-full p-3 border rounded-xl"
                  required
                />
                <input
                  type="email"
                  name="email"
                  placeholder="Email"
                  value={formData.email}
                  onChange={handleInputChange}
                  className="w-full p-3 border rounded-xl"
                  required
                />
                <input
                  type="password"
                  name="password"
                  placeholder="Password"
                  value={formData.password}
                  onChange={handleInputChange}
                  className="w-full p-3 border rounded-xl"
                  required
                />
                <button
                  type="submit"
                  className="w-full bg-blue-600 text-white py-3 rounded-xl hover:bg-blue-700"
                >
                  Sign Up
                </button>
              </form>
            </div>
          </div>
        );

      case "home":
        return (
          <div className="min-h-screen bg-gray-50">
            <Navbar />
            <header className="relative h-96 bg-gradient-to-r from-blue-600 to-purple-700 text-white flex items-center justify-center">
              <img
                src="/assets/hero-poster.jpg"
                alt="Hero"
                className="absolute inset-0 w-full h-full object-cover opacity-40"
              />
              <div className="relative text-center">
                <h2 className="text-4xl font-bold mb-4">Elevate Your Brand</h2>
                <p className="mb-6">
                  AI-powered promotion for businesses of all sizes
                </p>
                <button
                  onClick={() => setPage("promotionSelect")}
                  className="bg-white text-blue-600 px-6 py-3 rounded-full font-semibold"
                >
                  Create Promotion
                </button>
              </div>
            </header>
            <main className="p-6 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {campaigns.map((c, idx) => (
                <div
                  key={idx}
                  className="bg-white rounded-xl shadow-md p-4 hover:shadow-lg transition"
                >
                  <h3 className="font-bold text-lg">{c.name}</h3>
                  <p className="text-sm text-gray-600">{c.type}</p>
                  <p className="mt-2">Target: {c.target}</p>
                  <p>Budget: {c.budget}</p>
                </div>
              ))}
            </main>
          </div>
        );

      case "promotionSelect":
        return (
          <div className="min-h-screen bg-gray-100 flex items-center justify-center p-6">
            <div className="bg-white p-8 rounded-xl shadow-md w-full max-w-lg">
              <h2 className="text-xl font-bold mb-4">Select Promotion Type</h2>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  setPage("promotionDetails");
                }}
                className="space-y-4"
              >
                <select
                  name="campaignType"
                  value={formData.campaignType}
                  onChange={handleInputChange}
                  className="w-full p-3 border rounded-xl"
                  required
                >
                  <option value="">-- Select --</option>
                  <option value="product">Product Promotion</option>
                  <option value="service">Service Promotion</option>
                </select>
                <button
                  type="submit"
                  className="w-full bg-blue-600 text-white py-3 rounded-xl hover:bg-blue-700"
                >
                  Next
                </button>
              </form>
            </div>
          </div>
        );

      case "promotionDetails":
        return (
          <div className="min-h-screen bg-gray-100 flex items-center justify-center p-6">
            <div className="bg-white p-8 rounded-xl shadow-md w-full max-w-lg">
              <h2 className="text-xl font-bold mb-4">Campaign Details</h2>
              <form onSubmit={handleSubmit} className="space-y-4">
                <input
                  type="text"
                  name="campaignName"
                  placeholder="Campaign Name"
                  value={formData.campaignName}
                  onChange={handleInputChange}
                  className="w-full p-3 border rounded-xl"
                  required
                />
                <input
                  type="text"
                  name="targetAudience"
                  placeholder="Target Audience"
                  value={formData.targetAudience}
                  onChange={handleInputChange}
                  className="w-full p-3 border rounded-xl"
                  required
                />
                <input
                  type="text"
                  name="budget"
                  placeholder="Budget"
                  value={formData.budget}
                  onChange={handleInputChange}
                  className="w-full p-3 border rounded-xl"
                  required
                />
                <button
                  type="submit"
                  className="w-full bg-blue-600 text-white py-3 rounded-xl hover:bg-blue-700"
                >
                  Next
                </button>
              </form>
            </div>
          </div>
        );

      case "promotionExtra":
        return (
          <div className="min-h-screen bg-gray-100 flex items-center justify-center p-6">
            <div className="bg-white p-8 rounded-xl shadow-md w-full max-w-lg">
              <h2 className="text-xl font-bold mb-4">
                {formData.campaignType === "product"
                  ? "Product Details"
                  : "Service Details"}
              </h2>
              <form onSubmit={handleSubmit} className="space-y-4">
                {formData.campaignType === "product" ? (
                  <>
                    <input
                      type="text"
                      name="productName"
                      placeholder="Product Name"
                      value={formData.product.productName}
                      onChange={(e) =>
                        setFormData((prev: any) => ({
                          ...prev,
                          product: { ...prev.product, productName: e.target.value },
                        }))
                      }
                      className="w-full p-3 border rounded-xl"
                      required
                    />
                    <input
                      type="text"
                      name="productPrice"
                      placeholder="Product Price"
                      value={formData.product.productPrice}
                      onChange={(e) =>
                        setFormData((prev: any) => ({
                          ...prev,
                          product: { ...prev.product, productPrice: e.target.value },
                        }))
                      }
                      className="w-full p-3 border rounded-xl"
                      required
                    />
                    <textarea
                      name="productDesc"
                      placeholder="Product Description"
                      value={formData.product.productDesc}
                      onChange={(e) =>
                        setFormData((prev: any) => ({
                          ...prev,
                          product: { ...prev.product, productDesc: e.target.value },
                        }))
                      }
                      className="w-full p-3 border rounded-xl"
                      required
                    />
                  </>
                ) : (
                  <>
                    <input
                      type="text"
                      name="serviceName"
                      placeholder="Service Name"
                      value={formData.service.serviceName}
                      onChange={(e) =>
                        setFormData((prev: any) => ({
                          ...prev,
                          service: { ...prev.service, serviceName: e.target.value },
                        }))
                      }
                      className="w-full p-3 border rounded-xl"
                      required
                    />
                    <textarea
                      name="serviceDesc"
                      placeholder="Service Description"
                      value={formData.service.serviceDesc}
                      onChange={(e) =>
                        setFormData((prev: any) => ({
                          ...prev,
                          service: { ...prev.service, serviceDesc: e.target.value },
                        }))
                      }
                      className="w-full p-3 border rounded-xl"
                      required
                    />
                    <input
                      type="text"
                      name="serviceAudience"
                      placeholder="Target Audience"
                      value={formData.service.serviceAudience}
                      onChange={(e) =>
                        setFormData((prev: any) => ({
                          ...prev,
                          service: { ...prev.service, serviceAudience: e.target.value },
                        }))
                      }
                      className="w-full p-3 border rounded-xl"
                      required
                    />
                  </>
                )}
                <button
                  type="submit"
                  className="w-full bg-blue-600 text-white py-3 rounded-xl hover:bg-blue-700"
                >
                  Generate Post
                </button>
              </form>
            </div>
          </div>
        );

      case "postPreview":
        return (
          <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100 p-6">
            <div className="bg-white p-8 rounded-xl shadow-md w-full max-w-2xl text-center">
              <h2 className="text-2xl font-bold mb-4">Generated Post Preview</h2>
              <img
                src="/assets/ai-generated-sample.jpg"
                alt="Generated"
                className="w-full rounded-xl mb-4"
              />
              <p className="text-gray-700 mb-6">
                Your AI-powered promotional content is ready!
              </p>
              <button
                onClick={() => setPage("home")}
                className="bg-blue-600 text-white px-6 py-3 rounded-xl hover:bg-blue-700"
              >
                Back to Home
              </button>
            </div>
          </div>
        );

      case "analysis":
        return (
          <div className="min-h-screen bg-gray-50">
            <Navbar />
            <div className="p-6">
              <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                <BarChart2 /> Campaign Analysis
              </h2>
              <p className="text-gray-600">Analytics will appear here 📊</p>
            </div>
          </div>
        );

      case "chat":
        return (
          <div className="min-h-screen bg-gray-50">
            <Navbar />
            <div className="p-6">
              <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                <MessageSquare /> AI Chat Assistant
              </h2>
              <p className="text-gray-600">Chat feature coming soon 💬</p>
            </div>
          </div>
        );

      case "services":
        return (
          <div className="min-h-screen bg-gray-50">
            <Navbar />
            <div className="p-6">
              <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                <Layers /> Our Services
              </h2>
              <ul className="list-disc pl-6 text-gray-700 space-y-2">
                <li>AI-powered promotion</li>
                <li>Automated post generation</li>
                <li>Market analysis</li>
                <li>24/7 support</li>
              </ul>
            </div>
          </div>
        );

      case "about":
        return (
          <div className="min-h-screen bg-gray-50">
            <Navbar />
            <div className="p-6 text-center">
              <h2 className="text-2xl font-bold mb-4">About CERO</h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                CERO is a next-gen AI-powered promotion platform designed to
                help businesses grow online effortlessly 🚀
              </p>
            </div>
          </div>
        );

      default:
        return (
          <div className="h-screen flex items-center justify-center text-gray-600">
            <p>Page under construction 🚧</p>
          </div>
        );
    }
  };

  return <>{renderPage()}</>;
}