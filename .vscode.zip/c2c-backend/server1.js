// filepath: c2c-backend/server.js
const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 3001;

app.use(cors());
app.use(express.json());

app.post('/generate-plan', (req, res) => {
  const { businessName, businessType, goal } = req.body;

  let plan = '';
  let posts = [];

  if (businessType.toLowerCase().includes('cafe') || businessType.toLowerCase().includes('restaurant')) {
    plan = `Today's plan for ${businessName}: Share mouth-watering food photos, offer a limited-time discount, and encourage reviews to achieve your goal: ${goal}.`;
    posts = [
      `Craving something delicious? Visit ${businessName} today and enjoy a special offer!`,
      `Share your experience at ${businessName} and get 10% off your next meal.`,
      `Don't miss our chef's special at ${businessName} this week!`
    ];
  } else if (businessType.toLowerCase().includes('salon')) {
    plan = `Today's plan for ${businessName}: Post before-and-after transformations, promote a new service, and run a referral contest to achieve your goal: ${goal}.`;
    posts = [
      `Transform your look at ${businessName}! Book now for exclusive deals.`,
      `Refer a friend to ${businessName} and both get 20% off your next appointment.`,
      `See our latest styles and trends at ${businessName}.`
    ];
  } else if (businessType.toLowerCase().includes('shop')) {
    plan = `Today's plan for ${businessName}: Highlight best-selling products, announce flash sales, and engage with customers online to achieve your goal: ${goal}.`;
    posts = [
      `Flash Sale at ${businessName}! Hurry, limited time only.`,
      `Discover our top picks at ${businessName} and save big today.`,
      `Shop local, shop smart at ${businessName}.`
    ];
  } else {
    plan = `Today's plan for ${businessName}: Share what makes your business unique, offer a special promotion, and connect with your audience to achieve your goal: ${goal}.`;
    posts = [
      `Experience the difference at ${businessName}. Contact us for today's special offer!`,
      `We're here to help you achieve more at ${businessName}.`,
      `Follow ${businessName} for updates and exclusive deals.`
    ];
  }

  res.json({
    plan,
    posts
  });
});

app.get('/', (req, res) => {
  res.send('Backend is running!');
});

app.listen(PORT, () => {
  console.log(`Backend running at http://localhost:${PORT}`);
});